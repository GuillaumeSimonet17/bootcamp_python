from setuptools import setup

setup(
    name='my_minipack',
    version='1.0.0',
    packages=['my_minipack'],
    install_requires=[
        # Les dépendances de votre package
    ],
)
